package uta_parking.model;

public class PaymentErrorMsgs {
	
	private String paymentError;
	
	public PaymentErrorMsgs()
	{
		this.paymentError = "";
	}
	
	
	public void setPaymentError(String paymentError)
	{this.paymentError = paymentError;}
	
	
	public String getPaymentError() {
	return paymentError;
	}

}
