package uta_parking.model;

public class LoginErrorMsgs {
	
	private String loginError;
	
	public LoginErrorMsgs()
	{
		this.loginError = "";
	}
	
	
	public void setLoginError(String loginError)
	{this.loginError = loginError;}
	
	
	public String getLoginError() {
	return loginError;
	}
}
